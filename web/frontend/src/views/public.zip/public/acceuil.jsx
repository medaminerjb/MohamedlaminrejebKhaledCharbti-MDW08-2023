import all from '../../index2.css'; 
import {createBrowserRouter} from "react-router-dom"
import Header from '../../components/header';

import Footer from '../../components/footer';
import Container from '../../components/conatiner';
import Reash from '../../form/resarch';



export default function Acceuil(){
     
    return(
      <div>
 
<Header/>


<div class="landing">
      
      <div > <Reash/></div>
    
   </div>
  
   <Footer />
   </div>
      )


}