import {useEffect, useState} from "react";
import axiosClient from "../../axios-client.js";
import {Link,useParams,useNavigate} from "react-router-dom";
import {useStateContext} from "../../context/ContextProvider.jsx";
import Calendar from "react-calendar";
import 'react-calendar/dist/Calendar.css'
import  QRCode  from "react-qr-code";
import Header from "../../components/header.jsx";
import Footer from "../../components/footer.jsx";
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import axios from "axios";
import moment from 'moment';
import { addDays } from "date-fns";



export default function LigneClient(){
    const navigate = useNavigate();
    let {id} = useParams();
    let voyageid
    const [diisabledDates, setDisabledDates] = useState([]);
    
    const [selectedDate, setSelectedDate] = useState(new Date());
   
      const [billet, setBillet] = useState({
        id: null,
        numero: '5',
        validite: 'valide',
        reservations_id: '',
        
      })
      const [reserve, setReserve] = useState({
        id: null,
      
        date: '',
        voyage_id: '',
        entreprise_id : ''
        
      })
      const [reservatione , setReservation] = useState({
        id:null,
        nbrptotal:'50',
        nbrpoccupe:'1',
        voyagedate:'01/01/2022',
        etat: 'empty',
        voyage_id:'1',

      })
      const [reservatione2 , setReservation2] = useState({
        id:null,
        nbrptotal:'50',
        nbrpoccupe:'0',
        voyagedate:'01/01/2022',
        etat: 'empty',
        voyage_id:'1',

      })
     
    
    const[voyage,setVoyage] = useState([]);
    
    const [lignes, setLignes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [loading2, setLoading2] = useState(false);
  const [reserveee, setReserveee] = useState(true);
  const [reservationss, setReservationss] = useState(false);
  const [des, setDes] = useState({
    id: null,
   voyage_id:'',
   voyagedate:''
  })
  const[entreprise,setentreprise] = useState([]);
  const {setNotification} = useStateContext()
 
  if (id) {
    useEffect(() => {
      setLoading(true)
      axiosClient.get(`/gligne/${id}`)
        .then(({data}) => {
          setLoading(false)
          setLignes(data)
        }),
        axiosClient.get(`/voyage/${id}`).then(({data}) => {
          setLoading(false)
          setVoyage(data)
        })
        .catch(() => {
          setLoading(false)
        })
        axiosClient.get('/getentreall').then(({data}) => {
          setLoading(false)
          setentreprise(data)
        })
    }, [])
  }
  const change=()=>{
    disab();
  }
  const disab=()=>{
    useEffect(() => {
    
    axiosClient.get(`/getdate/${des.voyage_id}`)
      .then(({data}) => { 
        setDisabledDates(data)
      }) .catch(() => {
        setLoading(false)
      })
  }, [])
  
    }
    
   let er
    const onReserve = ev => {
      ev.preventDefault()
      
 
      axiosClient.get(`getreserve/${reserve.voyage_id},${reserve.date}`)
      .then((response) => {
      setReservation(response.data)
      
       let reservatione = response.data[0]
      
       
       if(response.data.length === 0){
        console.log('rjb')
       alert('the date ne pas disponible pour le moment ')
       setReserveee(true)
       
  
   
        
        
       }});

       axiosClient.get(`getreserve/${reserve.voyage_id},${reserve.date}`)
      .then((response) => {


      setReservation(response.data)
      
       let reservatione = response.data[0]
       
       console.log(reservatione.nbrpoccupe)
       if(reservatione.nbrpoccupe =='50'){
        reservatione.etat='full'
        axiosClient.put(`/reserveputetat/${reservatione.id}`, reservatione)
        .then(() => {
          setNotification('User was successfully updated')
       
          
        })
        setNotification('the reservation is full')
        console.log('hello')
      
      }
      if( reservatione.nbrpoccupe < '50')
      { 
    reservatione.nbrpoccupe=reservatione.nbrpoccupe+1
billet.reservations_id=reservatione.id
    axiosClient.post(`newbillet/`, billet).then(response => {
      const data = response.data
      setBillet(data)
      console.log(billet)
      navigate('/billet/'+response.data+'/'+reservatione.voyage_id+'/'+lignes.id+'/'+billet.reservations_id)
    

    })



    axiosClient.put(`/reserveput/${reservatione.id}`, reservatione)
    .then(() => {
      setNotification('User was successfully updated')
   
      
    }).catch(console.log('eror'))

        console.log('hiiii')
      }
      
        
      }).catch(()=>{console.log('3asba123')})
    
  
    
    


    }
  
var num =0;
  function Reserve() {
  
  if(!loading2){
   setLoading2(true)

  }
  else{setLoading2(false)}

}
const rjb=()=>{
  setLoading2(false);
  }
  let  date 
  const [error, setError] = useState(null)
  const [voyagedatee,setVoyagedate] = useState([]);



  const getDate = (v_id ,e_id) => {
    reserve.voyage_id=v_id
    reserve.entreprise_id=e_id
    console.log(reserve.voyage_id+'test'+e_id)

    axiosClient.get(`getdate/${v_id}/${e_id}`)
      .then((reponse) => {

       setVoyagedate(reponse.data)
       console.log(reponse.data)
       setReservationss(true)
       console.log(voyagedatee.voyagedate)
      
        
      }).then (data=>{
        // Map API response to Moment.js objects
        const disabledDatesArray = data.map(date => moment(date, 'YYYY-MM-DD'));
        // Set disabled dates in state
        setDisabledDates(disabledDatesArray);
      console.log(diisabledDates)
      }).catch((error)=>
      {console.log(error)});
      
  }
  const disable = Object.keys(voyagedatee).map(index => {
    return`${voyagedatee[index].voyagedate}`;
  });
 
  const diss = voyagedatee.map(item => item.name);
  
  
  const handleDateChange = (event) => {
    const selectedDate = event.target.value;
    const isDisabled = disable.includes(selectedDate);
    if (isDisabled) {
      event.target.value = ''; // Clear the selected value
      alert('the date selected is full try other date please');
    }
  };


  const isDateDisabled = date => {
    const formattedDate = date.toISOString().split('T')[0];
    return diisabledDates.includes(formattedDate);
  };

 /* const voyagess=voyage.map((v => (
    
    <tr key={v.id}>
     
    <td>{lignes.numero}</td>
    <td>{v.temps}</td>
      <td>{lignes.depart}</td>
      <td>{lignes.arrive}</td>
      <td>{lignes.distance}km</td>
      <td>{lignes.prix} d</td>
      <td> {v.entreprise_id}</td>
      <td>
                  <button className="btn-edit"onClick={ev => getDate(v.id)} >Reserve </button>
                  &nbsp;</td>
   

   </tr>)))*/


   const voyagess=voyage.map((v => (
    
    <tr key={v.id}>
     
    <td>{lignes.numero}</td>
    <td>{v.temps}</td>
      <td>{lignes.depart}</td>
      <td>{lignes.arrive}</td>
      <td>{lignes.distance}km</td>
      <td>{lignes.prix} d</td>
       {entreprise.map((e =>(

      <td> {v.entreprise_id==e.id&&e.name} <button className="btn-edit"onClick={ev => getDate(v.id,e.id)} >Reserve </button></td>
      

    
      
      )))}
      
   

   </tr>)))
   
    des.voyagedate=selectedDate
 

var voyages = Object.values(voyage);
var voyagedat = Object.values(voyagedatee)
function getFormattedDate() {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}




return(
  <div>
 
  <Header/>
  
  
  <div class="landing">
        
  <div>
      <div style={{display: 'flex', justifyContent: "space-between", alignItems: "center"}}>
     
      
      <br />  <br />  <br />
        
      </div>
      <div className="card animated fadeInDown">
      
      <h1 >ligne {lignes.depart} vers {lignes.arrive}</h1>
      <br/>
        <table>
          <thead>
          <tr>
            <th>numero</th>
            <th>temps</th>
            <th>depart</th>
            <th>arrive</th>
            <th>distance</th>
            <th>prix</th>
            <th></th>
            

        
          </tr>
          </thead>
          {loading &&
            <tbody>
            <tr>
              <td colSpan="5" class="text-center">
                Loading...
              </td>
            </tr>
            </tbody>
          }
          {!loading &&
            <tbody>
         {voyagess}
       
    
    
            </tbody>
          }
        </table>
        <div className="formticket">
      <div className="form3">
  <br />
  {
    reservationss&&
    <div>
     
    <form onSubmit={onReserve}>
      
            
   
    <input value={selectedDate} disabled={diss.includes(selectedDate)} min={getFormattedDate()} type="date" id="myDateInput" onChange={ev=>{handleDateChange(ev),setReserve({...reserve,date:ev.target.value})}} />
    
    

    <button className="btn">reserve</button>
  </form>
    </div>
    
    
     
     }

 
        {loading2&&
        <button className="btn-res" onClick={Reserve}>Annuler</button>}
        <br />
        &nbsp;
        {
        loading2&&

       
        <form onSubmit={Reserve}>
          <h1 className="title">get ticket</h1>
<br />






          
          <DatePicker
  selected={selectedDate}
  
  onChange={date => setSelectedDate(date)}
  minDate={new Date()}
      dateFormat="yyyy/MM/dd"
      excludeDates={disabledDatess}
/>
        
        </form>
      
    }
    </div></div>
      </div>
    </div>
      
     </div>
    
     <Footer />
     </div>
   
  )}