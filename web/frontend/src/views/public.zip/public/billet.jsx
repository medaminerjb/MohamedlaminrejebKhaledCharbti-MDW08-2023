import {useEffect, useState} from "react";
import axiosClient from "../../axios-client.js";
import {Link,useParams,useNavigate} from "react-router-dom";
import  QRCode  from "react-qr-code";
import Header from "../../components/header.jsx";
import Footer from "../../components/footer.jsx";
import DatePicker from 'react-datepicker';
import all from "./style.css"
import html2canvas from "html2canvas";
import domtoimage from 'dom-to-image';
import jsPDF from "jspdf";

const convertToImg = () => {
  const element = document.getElementById('htmlContent');

  const options = {
    quality: 1, // Set the quality level to 1 (highest)
  };

  domtoimage.toPng(element, options)
    .then(dataUrl => {
      const link = document.createElement('a');
      link.href = dataUrl;
      link.download = 'output.png';
      link.click();
    })
    .catch(error => {
      console.error('Error converting HTML to image:', error);
    });
};
const convertToPDF = () => {
   const pdf = new jsPDF('p', 'pt', 'letter');
   const element = document.getElementById('htmlContent');
 
   pdf.html(element, {
     callback: () => {
       pdf.save('output.pdf');
     }
   });
 };
export default function Billet(){


    const navigate = useNavigate();
    let {numero,reservation_id,lignes_id,id} = useParams();
    const currentDate = new Date();
   
    const formattedDate = currentDate.toLocaleDateString('en-CA', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).replace(/\//g, '/');
  
    


    const [billet, setBillet] = useState({
        id: null,
        numero: '',
        validite: '',
        reservations_id: '',
        
      })
      const [billet2, setBillet2] = useState({
         id: null,
         numero: '',
         validite: '',
         reservations_id: '',
         
       })
      const [voyage, setVoyage] = useState({
        id: null,
        temps: '',
        lignes_id: '',
      })
      const [ligne, setLigne] = useState({
        id: null,
        numero: '',
        depart: '',
        arrive: '',
        prix: '',
        distance:''
      })
      const [reservation , setReservation] = useState({
         id:null,
         nbrptotal:'',
         nbrpoccupe:'',
         voyagedate:'',
         etat: '',
         voyage_id:'',
       })
      let numer
      let valaidite 
      let reservations_id 
    const [loading, setLoading] = useState(false);
    const [loading2, setLoading2] = useState(false);
    const [loading3, setLoading3] = useState(false);
    const [page, setPage] = useState(false);
    const [ready, setready] = useState(false);
const [rexx,setRex] = useState({})


  
  let datee = new Date(reservation.voyagedate)
  if (numero&&!ready) {
   useEffect(() => {
    
     axiosClient.get(`/billet/${numero}`)
       .then(({data}) => {
       setBillet(data[0])
       });
       axiosClient.get(`/getvoyage/${reservation_id}`)
       .then(({data}) => {
       setVoyage(data)
       });
       axiosClient.get(`/vm/${lignes_id}`).then(({data}) => {
       
         setLigne(data)
  
         });
         axiosClient.get(`/getrb/${id}`)
      .then(({data}) => {
        
      setReservation(data[0])
      });
      
      },[]);

   }
   if(billet.id&&reservation.id&&ligne.id){
      setready(true)
   }
   
 let billetetat
  if(( reservation.voyagedate < formattedDate)&&(billet.reservations_id==id))
{
   billetetat=" non validie"
 axiosClient.put(`/putbilletetat/${billet.id}`,billet).then(() => {
  
     
 });
 axiosClient.get(`/billet/${numero}`)
       .then(({data}) => {
        
       setBillet2(data[0])
      
       });

 
}
else{billetetat="validie"}


let test = 0
console.log(reservation.id+'rjb'+billet.reservations_id)
if(reservation.id&&billet.reservations_id&&(reservation.id !== billet.reservations_id))
{
   
   test = 0
  
 
}
else{test=1}

console.log(test)



   
   
 
let res = rexx[0]    
let bi = billet    
let vo = voyage[0]   
let li = ligne[0]





      
       
      





        return (
        <div class="body">
      
          <main class="ticket-system" >
            
             <div class="top">
             <br/>
      <br/>
{test==1&&!li&&
             <h1 class="title">Wait a second, your ticket is being printed</h1>
}
{
   bi&&vo&&li&&test==0&&
   <h1 class="title">check if the ticket exist </h1>

}
{
               li&&bi&&vo&&test==1&& <button class="btn" onClick={convertToImg}>" click pour telecharger   "</button>
             }<div class="printer" />
         
             </div>
           
             {
         li&&bi&&vo&&test==1&&        <div >  <div class="receipts-wrapper" >
            
                <div class="receipts" >
               
                   <div class="receipt"  >
                   
                      <div class="route">
                         <h2>{li.depart}</h2>
                       
                         <h2>{li.arrive}</h2>
                      </div>
                      <div class="details">
                         <div class="item">
                            <span>Passanger</span>
                            <h3>bus</h3>
                         </div>
                         <div class="item">
                            <span>ticket No.</span>
                            <h3>{numero}</h3>
                         </div>
                         <div class="item">
                            <span>Departure</span>
                            <h3>{vo.temps}</h3>
                         </div>
                         <div class="item">
                            <span>prix</span>
                            <h3>{li.prix} d</h3>
                         </div>
                         <div class="item">
                            <span>etat</span>
                            <h3>{billetetat}</h3>
                         </div>
                         <div class="item">
                            <span>date</span>
                            <h3>{reservation.voyagedate}</h3>
                         </div>
                      </div>
                   </div>
                   <div class="receipt qr-code" id="htmlContent">
                     
                      <QRCode value={"localhost:3000/billet/"+numero+"/"+reservation_id+"/"+lignes_id+'/'+id} size={69}/>
                      
                      <div class="description">
                         <h2>69Pixels</h2>
                         <p>Scan QR-code </p>
                      </div>
                   </div>
                </div>
             </div>
             </div>
}
<div><br /><br /></div><div><br /><br /></div>
        </main>
       </div>
          
        )


}