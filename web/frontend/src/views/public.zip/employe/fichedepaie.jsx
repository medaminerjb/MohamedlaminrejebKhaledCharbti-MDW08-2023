import {useNavigate, useParams} from "react-router-dom";
import {useEffect, useState} from "react";
import axiosClient from "../../axios-client.js";
import {useStateContext} from "../../context/ContextProvider.jsx";
import Selectl from "../../components/selectligne.jsx";
import { Link } from "react-router-dom";
import all from "./css.css";
import styled from 'styled-components';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
const convertToImg = () => {
    const element = document.getElementById('htmlContent');
  
    html2canvas(element, { useCORS: true })
      .then(canvas => {
        const imageData = canvas.toDataURL('image/png');
  
        const link = document.createElement('a');
        link.href = imageData;
        link.download = 'output.png';
        link.click();
      })
      .catch(error => {
        console.error('Error converting HTML to image:', error);
      });
  };
  const convertToPDF = () => {
    const pdf = new jsPDF('p', 'pt', 'letter');
    const element = document.getElementById('htmlContent');
  
    pdf.html(element, {
      callback: () => {
        pdf.save('output.pdf');
      }
    });
  };
export default function Fiche() {
  const navigate = useNavigate();
  const {iduser,setUserid}=useStateContext();
  const [loading, setLoading] = useState(false)
  const [verifpointage, setVerifpointage] = useState(false)
  const {setNotification} = useStateContext()
  const currentjour = new Date().getDate() 
  const currentMonth = new Date().getMonth()+1
  const currentyear = new Date().getFullYear()
  const [userinf, setUserinf] = useState({
    id: null,
    name: '',
    email: '',
    telephone: '',
    adresse: '',
    poste:'',
    salaire:'',
    entreprise_id:'',
    user_id:''
  })
  const [pointage, setPointage] = useState({
    id: null,
    nombredejour: '',
    currentjour: '',
    currentmois: '',
    conjirestant:'',
    user_id:''
  })
  const [fiche, setFiche] = useState({
    id: null,
    nombredejour: '0',
    conjirestant: '0',
    salaire: '0',
    entreprise_id:'',
    user_id:''
  })
  if (iduser) {
    useEffect(() => {
      setLoading(true)
      axiosClient.get(`/getemploye/${iduser}`)
        .then(({data}) => {
          setLoading(false)
          setUserinf(data[0])
         
        })
        .catch(() => {
          setLoading(false)
        });
        axiosClient.get(`/getpointage/${iduser}`)
        .then(({data}) => {
          setLoading(false)
          setPointage(data[0])
       
        })
        .catch(() => {
          setLoading(false)
        });
        axiosClient.get(`/getfichedp/${iduser}`)
        .then(({data}) => {
          setLoading(false)
          setFiche(data[0])
          console.log(data[0])
            if(data.length == 0&&userinf.entreprise_id)
            {fiche.entreprise_id=userinf.entreprise_id
                fiche.user_id=iduser
                axiosClient.post('/newfiche', fiche)
                .then(() => {
                  setNotification('fiche creted succes ')
                  navigate('/fiche')
                })
                
            }



        })
        .catch(() => {
          setLoading(false)
        });
        

    }, [])
  }

    if((currentMonth>pointage.currentmois)&&(pointage.currentmois>0))
    {
            fiche.conjirestant=pointage.nombredejour-26
           
           if(pointage.nombredejour>26)
            { fiche.salaire=userinf.salaire}
            else(fiche.salaire=(userinf.salaire/26)*pointage.nombredejour)
            fiche.nombredejour=pointage.nombredejour


        axiosClient.put(`/fiche/${fiche.id}`, fiche)
        .then(() => {
        
          
        })
        axiosClient.get(`/getfichedp/${iduser}`)
        .then(({data}) => {
          setLoading(false)
          setFiche(data[0])});
    }
    const Container = styled.div`/* reset */

    *
    {
        border: 0;
        box-sizing: content-box;
        color: inherit;
        font-family: inherit;
        font-size: inherit;
        font-style: inherit;
        font-weight: inherit;
        line-height: inherit;
        list-style: none;
        margin: 0;
        padding: 0;
        text-decoration: none;
        vertical-align: top;
    }
    
    /* content editable */
    
    *[contenteditable] { border-radius: 0.25em; min-width: 1em; outline: 0; }
    
    *[contenteditable] { cursor: pointer; }
    
    *[contenteditable]:hover, *[contenteditable]:focus, td:hover *[contenteditable], td:focus *[contenteditable], img.hover { background: #DEF; box-shadow: 0 0 1em 0.5em #DEF; }
    
    span[contenteditable] { display: inline-block; }
    
    /* heading */
    
    h1 { font: bold 100% sans-serif; letter-spacing: 0.5em; text-align: center; text-transform: uppercase; }
    
    /* table */
    
    table { font-size: 75%; table-layout: fixed; width: 100%; }
    table { border-collapse: separate; border-spacing: 2px; }
    th, td { border-width: 1px; padding: 0.5em; position: relative; text-align: left; }
    th, td { border-radius: 0.25em; border-style: solid; }
    th { background: #EEE; border-color: #BBB; }
    td { border-color: #DDD; }*/
    
    /* page */
    
    html { font: 16px/1 'Open Sans', sans-serif; overflow: auto; padding: 0.5in; }
    html { background: #999; cursor: default; }
    
    body { box-sizing: border-box; height: 11in; margin: 0 auto; overflow: hidden; padding: 0.5in; width: 8.5in; }
    body { background: #FFF; border-radius: 1px; box-shadow: 0 0 1in -0.25in rgba(0, 0, 0, 0.5); }
    
    /* header */
    
    header { margin: 0 0 3em; }
    header:after { clear: both; content: ""; display: table; }
    
    header h1 { background: #000; border-radius: 0.25em; color: #FFF; margin: 0 0 1em; padding: 0.5em 0; }
    header address { float: left; font-size: 75%; font-style: normal; line-height: 1.25; margin: 0 1em 1em 0; }
    header address p { margin: 0 0 0.25em; }
    header span, header img { display: block; float: right; }
    header span { margin: 0 0 1em 1em; max-height: 25%; max-width: 60%; position: relative; }
    header img { max-height: 100%; max-width: 100%; }
    header input { cursor: pointer; -ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=0)"; height: 100%; left: 0; opacity: 0; position: absolute; top: 0; width: 100%; }
    
    /* article */
    
    article, article address, table.meta, table.inventory { margin: 0 0 3em; }
    article:after { clear: both; content: ""; display: table; }
    article h1 { clip: rect(0 0 0 0); position: absolute; }
    
    article address { float: left; font-size: 125%; font-weight: bold; }
    
    /* table meta & balance */
    
    table.meta, table.balance { float: right; width: 36%; }
    table.meta:after, table.balance:after { clear: both; content: ""; display: table; }
    
    /* table meta */
    
    table.meta th { width: 40%; }
    table.meta td { width: 60%; }
    
    /* table items */
    
    table.inventory { clear: both; width: 100%; }
    table.inventory th { font-weight: bold; text-align: center; }
    
    table.inventory td:nth-child(1) { width: 26%; }
    table.inventory td:nth-child(2) { width: 38%; }
    table.inventory td:nth-child(3) { text-align: right; width: 12%; }
    table.inventory td:nth-child(4) { text-align: right; width: 12%; }
    table.inventory td:nth-child(5) { text-align: right; width: 12%; }
    
    /* table balance */
    
    table.balance th, table.balance td { width: 50%; }
    table.balance td { text-align: right; }
    
    /* aside */
    
    aside h1 { border: none; border-width: 0 0 1px; margin: 0 0 1em; }
    aside h1 { border-color: #999; border-bottom-style: solid; }
    
    /* javascript */
  
    
   

    
    @page { margin: 0; } `;
    
     
return(
<Container>

<body>

<h1>Telecharger votre fiche  <br/>  <button class="btn" onClick={convertToPDF}>" PDF  Click ici   "</button>
<br/> <br/>
<button class="btn" onClick={convertToImg}>"  Image Click ici   "</button>

</h1>
<br/>

     <div id="htmlContent">
       
       
        
		<header>
			<h1>Fiche de paie</h1>
			<address contenteditable>
				<p>{userinf.name}</p>
				<p>{userinf.adresse}<br/>{userinf.telephone}</p>
				
			</address>
			
		</ header>
		<article>
			<h1>FICHE DE PAIE</h1>
			<address contenteditable>
			
			</address>
			<table class="meta">
				<tr>
					<th><span contenteditable>Poste</span></th>
					<td><span contenteditable>{userinf.poste}</span></td>
				</tr>
				<tr>
					<th><span contenteditable>Date</span></th>
					<td><span contenteditable>{currentyear}/{currentMonth}/{currentjour}</span></td>
				</tr>
				<tr>
					<th><span contenteditable>Salaire de base</span></th>
					<td><span id="prefix" contenteditable>dinar </span><span>{userinf.salaire}</span></td>
				</tr>
			</table>
			<table class="inventory">
				<thead>
					<tr>
						<th><span contenteditable>nombre de jour</span></th>
                        <th><span contenteditable>salaire de base  </span></th>
						<th><span contenteditable>Conji Restant</span></th>
					
						
						<th><span contenteditable>Salaire recue</span></th>
					</tr>
				</thead>
				<tbody>
					<tr>
                    <td><span contenteditable>{!fiche.nombredejour&&0 }{fiche.nombredejour}</span></td>
						<td><span contenteditable>dinar{userinf.salaire}</span></td>
						
						<td><span data-prefix> </span><span contenteditable>{fiche.conjirestant+0.0}</span></td>
						<td><span data-prefix>dinar </span><span>{fiche.salaire }</span></td>
					</tr>
				</tbody>
			</table>
		
			<table class="balance">
				<tr>
					<th><span contenteditable>Total</span></th>
					<td><span data-prefix>dinar </span><span>{userinf.salaire}</span></td>
				</tr>
				<tr>
					<th><span contenteditable>Tax</span></th>
					<td><span data-prefix>dinar </span><span contenteditable>0.00</span></td>
				</tr>
				<tr>
					<th><span contenteditable>Salaire de Obtenu</span></th>
					<td><span data-prefix>dinar</span><span>{fiche.salaire}</span></td>
				</tr>
			</table>
		</article>
		<aside>
			<h1><span contenteditable>Additional Notes</span></h1>
			<div contenteditable>
				<p>A finance charge of 1.5% will be made on unpaid balances after 30 days.</p>
			</div>
		</aside>
        </div> 
       
</body>
    </Container>
    )
}