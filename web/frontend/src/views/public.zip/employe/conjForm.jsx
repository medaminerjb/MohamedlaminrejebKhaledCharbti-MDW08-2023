import {Link, useNavigate, useParams} from "react-router-dom";
import {useEffect, useState} from "react";
import axiosClient from "../../axios-client.js";
import {useStateContext} from "../../context/ContextProvider.jsx";
import Selectl from "../../components/selectligne.jsx";


export default function ConjiForm() {
  const navigate = useNavigate();
  const {user,setUser}=useStateContext();
  const [conjicheck, setConjicheck] = useState(false)
   const {iduser,setUserid} = useStateContext();
  const [employe, setEmploye]=useState([])
  const [conji, setConji] = useState({
    id: null,
    name: '',
  reason:'',
  nbrjr:'',
  date:'',
user_id:'',
etat:'non verifé'
  })
  const [conji2, setConji2] = useState({
    id: null,
    name: '',
  reason:'',
  nbrjr:'',
  date:'',
user_id:'',
etat:''
  })
conji.user_id=iduser

  const [errors, setErrors] = useState(null)
  const [loading, setLoading] = useState(false)
  const {setNotification} = useStateContext()
  useEffect(() => {
    setLoading(true)
    axiosClient.get(`/conjicheck/${iduser}`)
      .then(({data}) => {
        setLoading(false)
        setConji2(data)
        console.log(data)
       
      }).catch(() => {
        setLoading(false)
      })
  }, [])
const clickold = ()=>{
  if(!conjicheck)
  {setConjicheck(true)}
 else{setConjicheck(false)}

}
  
  const onSubmit = ev => {
    ev.preventDefault()
    
      axiosClient.post('/conji', conji)
        .then(() => {
          setNotification('User was successfully created')
          navigate('/users')
        })
        .catch(err => {
          const response = err.response;
          if (response && response.status === 422) {
            setErrors(response.data.errors)
          }
        })
    
  }
  var co  = Object.values(conji2); 
  console.log(co)

 const currentMonth = new Date().getDate() 


 console.log(currentMonth+1)

  return (
    <>
       <div style={{display: 'flex', justifyContent: "space-between", alignItems: "center"}}>
      <h1>Pointage</h1>
    
     

      {!loading&&!conjicheck&&<button className="btn-add" to="/voyage/" onClick={clickold} >conji all  </button>}
      {!loading&&conjicheck&&<button className="btn-add" to="/fiche" onClick={clickold}>New Conji </button> }
    </div>
     <br />
   
      <div className="card animated fadeInDown">

        {loading && (
          <div className="text-center">
            Loading...
          </div>
        )}
        {errors &&
          <div className="alert">
            {Object.keys(errors).map(key => (
              <p key={key}>{errors[key][0]}</p>
            ))}
          </div>
        }
     
        {!loading && !conjicheck&&  (
          <form onSubmit={onSubmit}>
           
            <input value={conji.name} onChange={ev => setConji({...conji, name: ev.target.value})} placeholder="Name"/>
            
            <input value={conji.reason} onChange={ev => setConji({...conji, reason: ev.target.value})} placeholder="reasan"/>
            <input value={conji.nbrjr} onChange={ev => setConji({...conji, nbrjr: ev.target.value})} placeholder="nbr dejour"/>
            <input type="date" onChange={ev => setConji({...conji, date: ev.target.value})} placeholder="nbr dejour"/>
          

            <button className="btn">Save</button>
          </form>
        )}
      {!loading&&conjicheck&&  <div className="card animated fadeInDown">
        <table>
          <thead>
          <tr>
            <th>nombre de jourconji</th>
            <th>date de conji</th>
            <th>etat</th>
            <th>action</th>
           
          
            
          </tr>
          </thead>
          <tbody>
           
          {co.map(c => (
              <tr key={c.id}>
                <td>{c.nbrjr}</td>
                <td>{c.dateconji}</td>
                <td>{c.etat}</td>
              
                <td>
                  <Link className="btn-edit" to={'/users/' + c.id}>voir</Link>
                  &nbsp;
                  <button className="btn-delete" onClick={ev => onDeleteClick(c)}>Delete</button>
                </td>
              </tr>
            ))}
            </tbody>
            </table>
            </div>
      }
</div>
      </>


  )
}
